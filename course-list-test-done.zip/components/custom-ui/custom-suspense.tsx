const CustomSuspenseFallback = () => {
  return <div>Loading...</div>;
};

export default CustomSuspenseFallback;
