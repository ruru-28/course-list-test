type CustomSonerProps = {
  user: null;
};

const CustomSoner: React.FC<CustomSonerProps> = () => {
  return <div></div>;
};

export default CustomSoner;
